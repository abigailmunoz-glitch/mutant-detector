package com.mercadolibre.mutantdetector.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Arrays;

public class DnaRequest {

    @NotNull(message = "DNA cannot be null")
    @Size(min = 4, message = "DNA must have at least 4 sequences")
    private String[] dna;

    public String[] getDna() {
        return dna;
    }

    public void setDna(String[] dna) {
        this.dna = dna;
    }

    @Override
    public String toString() {
        return "DnaRequest{" +
                "dna=" + Arrays.toString(dna) +
                '}';
    }
}