package com.mercadolibre.mutantdetector.dto;

public class StatsResponse {
    private long countMutantDna;
    private long countHumanDna;
    private double ratio;

    public StatsResponse() {}

    public StatsResponse(long countMutantDna, long countHumanDna) {
        this.countMutantDna = countMutantDna;
        this.countHumanDna = countHumanDna;
        this.ratio = countHumanDna == 0 ? 0 : (double) countMutantDna / countHumanDna;
    }

    // Getters and Setters
    public long getCountMutantDna() { return countMutantDna; }
    public void setCountMutantDna(long countMutantDna) { this.countMutantDna = countMutantDna; }

    public long getCountHumanDna() { return countHumanDna; }
    public void setCountHumanDna(long countHumanDna) { this.countHumanDna = countHumanDna; }

    public double getRatio() { return ratio; }
    public void setRatio(double ratio) { this.ratio = ratio; }
}