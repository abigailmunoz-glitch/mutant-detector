package com.mercadolibre.mutantdetector.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "dna_records", uniqueConstraints = {
        @UniqueConstraint(columnNames = "dnaHash")
})
public class DnaRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 1000)
    private String[] dna;

    @Column(nullable = false, unique = true)
    private String dnaHash;

    @Column(nullable = false)
    private boolean isMutant;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    // Constructores
    public DnaRecord() {
        this.createdAt = LocalDateTime.now();
    }

    public DnaRecord(String[] dna, String dnaHash, boolean isMutant) {
        this();
        this.dna = dna;
        this.dnaHash = dnaHash;
        this.isMutant = isMutant;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String[] getDna() { return dna; }
    public void setDna(String[] dna) { this.dna = dna; }

    public String getDnaHash() { return dnaHash; }
    public void setDnaHash(String dnaHash) { this.dnaHash = dnaHash; }

    public boolean isMutant() { return isMutant; }
    public void setMutant(boolean mutant) { isMutant = mutant; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}