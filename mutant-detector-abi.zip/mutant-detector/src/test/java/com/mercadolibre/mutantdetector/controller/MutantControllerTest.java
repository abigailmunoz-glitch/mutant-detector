package com.mercadolibre.mutantdetector.controller;

import com.mercadolibre.mutantdetector.dto.DnaRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class MutantControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testMutantEndpointReturns200() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"AAAA", "AAAA", "AAAA", "AAAA"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void testMutantEndpointReturns403() throws Exception {
        DnaRequest request = new DnaRequest();
        request.setDna(new String[]{"ACGT", "TGCA", "CATG", "GTAC"});

        mockMvc.perform(post("/api/v1/mutant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    void testStatsEndpoint() throws Exception {
        mockMvc.perform(get("/api/v1/stats"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.countMutantDna").exists())
                .andExpect(jsonPath("$.countHumanDna").exists())
                .andExpect(jsonPath("$.ratio").exists());
    }
}