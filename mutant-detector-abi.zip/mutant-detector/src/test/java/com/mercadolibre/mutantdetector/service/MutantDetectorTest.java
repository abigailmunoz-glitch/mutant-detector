package com.mercadolibre.mutantdetector.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

class MutantDetectorTest {

    private MutantDetector mutantDetector;

    @BeforeEach
    void setUp() {
        mutantDetector = new MutantDetector();
    }

    @Test
    void testMutantDnaHorizontal() {
        // 4 A's en primera fila + 4 T's en segunda fila = 2 secuencias
        String[] dna = {
                "AAAAT",
                "TTTTG",
                "CGTAC",
                "GCTAG",
                "ATCGA"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }

    @Test
    void testMutantDnaVertical() {
        // 4 A's en primera columna
        String[] dna = {
                "ACGT",
                "ACGT",
                "ACGT",
                "ACGT"
        };
        assertTrue(mutantDetector.isMutant(dna));
    }
    //@Test
    //void testMutantDnaDiagonal() {
        // Diagonal principal CLARA: A-A-A-A
        //String[] dna = {
                //"AXXX",  // [0,0] = A
                //"XAXX",  // [1,1] = A
                //"XXAX",  // [2,2] = A
                //"XXXA"   // [3,3] = A
        //};
        //assertTrue(mutantDetector.isMutant(dna));
    //}

    @Test
    void testHumanDna() {
        // Sin secuencias de 4 letras iguales
        String[] dna = {
                "ACGT",
                "CAGT",
                "TCGA",
                "GTAC"
        };
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void testExampleMutant() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"};
        assertTrue(mutantDetector.isMutant(dna));
    }

    @Test
    void testExampleHuman() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATTT", "AGACGG", "GCGTCA", "TCACTG"};
        assertFalse(mutantDetector.isMutant(dna));
    }

    @Test
    void testInvalidMatrixSize() {
        String[] dna = {"ATG", "CAG", "TTA"};
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(dna));
    }

    @Test
    void testInvalidDnaBase() {
        String[] dna = {"ATXG", "CAGT", "TTAT", "AGAA"};
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(dna));
    }

    @Test
    void testNullInput() {
        assertThrows(IllegalArgumentException.class, () -> mutantDetector.isMutant(null));
    }
}