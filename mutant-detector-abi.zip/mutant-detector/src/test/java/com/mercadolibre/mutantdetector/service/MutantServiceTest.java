package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.entity.DnaRecord;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class MutantServiceTest {

    @Mock
    private MutantDetector mutantDetector;

    @Mock
    private DnaRecordRepository dnaRecordRepository;

    @InjectMocks
    private MutantService mutantService;

    @Test
    void testIsMutantWhenAlreadyExists() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"};
        DnaRecord existingRecord = new DnaRecord(dna, "hash123", true);

        when(dnaRecordRepository.findByDnaHash(any())).thenReturn(Optional.of(existingRecord));

        boolean result = mutantService.isMutant(dna);

        assertTrue(result);
        verify(mutantDetector, never()).isMutant(any());
    }

    @Test
    void testIsMutantNewRecord() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATTT", "AGACGG", "GCGTCA", "TCACTG"};

        when(dnaRecordRepository.findByDnaHash(any())).thenReturn(Optional.empty());
        when(mutantDetector.isMutant(dna)).thenReturn(false);
        when(dnaRecordRepository.save(any())).thenReturn(new DnaRecord());

        boolean result = mutantService.isMutant(dna);

        assertFalse(result);
        verify(dnaRecordRepository).save(any());
    }

    @Test
    void testIsMutantSavesCorrectly() {
        String[] dna = {"ATGCGA", "CAGTGC", "TTATGT", "AGAAGG", "CCCCTA", "TCACTG"};

        when(dnaRecordRepository.findByDnaHash(any())).thenReturn(Optional.empty());
        when(mutantDetector.isMutant(dna)).thenReturn(true);
        when(dnaRecordRepository.save(any())).thenReturn(new DnaRecord());

        boolean result = mutantService.isMutant(dna);

        assertTrue(result);
        verify(dnaRecordRepository).save(any(DnaRecord.class));
    }
}