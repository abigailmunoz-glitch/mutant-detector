package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.dto.StatsResponse;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class StatsServiceTest {

    @Mock
    private DnaRecordRepository dnaRecordRepository;

    @InjectMocks
    private StatsService statsService;

    @Test
    void testGetStatsWithData() {
        when(dnaRecordRepository.countMutantDna()).thenReturn(40L);
        when(dnaRecordRepository.countHumanDna()).thenReturn(100L);

        StatsResponse stats = statsService.getStats();

        assertEquals(40L, stats.getCountMutantDna());
        assertEquals(100L, stats.getCountHumanDna());
        assertEquals(0.4, stats.getRatio());
    }

    @Test
    void testGetStatsZeroHumans() {
        when(dnaRecordRepository.countMutantDna()).thenReturn(10L);
        when(dnaRecordRepository.countHumanDna()).thenReturn(0L);

        StatsResponse stats = statsService.getStats();

        assertEquals(10L, stats.getCountMutantDna());
        assertEquals(0L, stats.getCountHumanDna());
        assertEquals(0.0, stats.getRatio());
    }

    @Test
    void testGetStatsZeroData() {
        when(dnaRecordRepository.countMutantDna()).thenReturn(0L);
        when(dnaRecordRepository.countHumanDna()).thenReturn(0L);

        StatsResponse stats = statsService.getStats();

        assertEquals(0L, stats.getCountMutantDna());
        assertEquals(0L, stats.getCountHumanDna());
        assertEquals(0.0, stats.getRatio());
    }
}